import { afterNextRender, Component, inject, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ThemeService } from './core/services/theme.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {

   private themeService =
    inject(ThemeService);

  constructor() {

    afterNextRender(() => {
      this.themeService.initTheme();
    });

  }
}
