import {
  Schema,
  model,
  Document,
  Types
} from 'mongoose';

export interface ISkill extends Document {
  cat_id: Types.ObjectId;
  user_id: Types.ObjectId;
  skill_name: string;
  skill_desc: string;
  skill_level: 1 | 2 | 3 | 4;
  skill_score?: string;
}

const skillSchema = new Schema<ISkill>(
  {
    cat_id: {
      type: Schema.Types.ObjectId,
      ref: 'SkillCategory',
      required: true,
    },

    user_id: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    skill_name: {
      type: String,
      required: true,
      trim: true,
    },

    skill_desc: {
      type: String,
      trim: true,
    },

    skill_level: {
      type: Number,
      enum: [1, 2, 3, 4],
      required: true,
    },

    skill_score: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

export const Skill = model<ISkill>(
  'Skill',
  skillSchema
);