import { z } from 'zod';

export const createSkillSchema = z.object({
    cat_id: z
        .string()
        .min(1, 'Category is required'),

    user_id: z
        .string()
        .min(1, 'User is required'),

    skill_name: z
        .string()
        .min(1, 'Skill name is required'),

    skill_desc: z
        .string()
        .optional(),

    skill_level: z
        .number()
        .min(1)
        .max(4),

    skill_score: z
        .string()
        .optional(),
});