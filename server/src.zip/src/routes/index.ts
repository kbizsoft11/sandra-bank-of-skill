import { Router } from 'express';

import userRouter from './user.route';
import authRouter from './auth.route';
import skillCategoryRoutes from "./skill-category.routes";
import { authenticate } from '../middlewares/auth.middleware';

const router = Router();

router.get('/', (_, res) => {
  res.json({
    success: true,
    message: 'Bank of Skill',
  });
});

router.use('/users', userRouter);
router.use('/auth', authRouter);
router.use('/skill-categories', authenticate, skillCategoryRoutes);

export default router;